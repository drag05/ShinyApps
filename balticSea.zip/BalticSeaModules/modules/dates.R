
selectUI <- function(id) {

          tagList(
                      , dateRangeInput('drang', 'Select Date Range'
                      , start = median(dt$Date)
                      , end = max(dt$Date)
                      , min = min(dt$Date)
                      , max = max(dt$Date)), height = '30px'

          , plotOutput(outputId = 'densTBO'
                       , height = '250px'
                       , width = '230px'
                      )

               )

}


selectServer <- function(id) {

                   moduleServer(id, 

                           function(input, output, session) {

                dt0 <- reactive({

               dt[between(Date,
                      lower = input$drang[1]
                    , upper = input$drang[2], NAbounds = NA)
                   ][order(Shipname, Date)]

            })


      output$densTBO <- renderPlot(

        ggplot(dt0(), aes(x = Date, y = Dist)) +
          geom_point(color = 'green', fill = 'green') + theme_bw() +
          scale_x_date('Day', date_labels = '%a', minor_breaks = NULL) +
          theme(axis.text.x = element_text(angle = 90)) +
          theme(axis.text.y = element_text(angle = 30)) +
          xlab('Day Of Week') + ylab('Distance (meters)') +
          facet_wrap(~ Ship.type)

                 )

