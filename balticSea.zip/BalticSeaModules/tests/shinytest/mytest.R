app <- ShinyDriver$new("../../")
app$snapshotInit("mytest")

app$setInputs(`filter1-shipname` = "FULDA")
app$snapshot()
