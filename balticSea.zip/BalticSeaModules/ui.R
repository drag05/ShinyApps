
shinyUI(

    navbarPage(title = div(img(src = ''
                         , style = "float:left; padding: 0px 20px; width: 10px")
                           , style = "color:darkmagenta"
                           , tags$b("Baltic Sea Naval Traffic"))
               , position = 'fixed-bottom', collapsible = TRUE
               , theme = shinythemes::shinytheme('spacelab')

   , tabPanel('Map',

    fluidPage(suppress_bootstrap = TRUE,

      tags$style(type = 'text/css'
                   , 'html
                   , body {width:100%;height:100%}')
                   , leafletOutput('BalticSea'
                                   , width = '100%', height = '550px')
                   , absolutePanel(top = 10, right = 5
                                   , width = '230px'


# call UI module data filter

        , selectUI('filter1')


                )

         )

     )



  , tabPanel('Data',

             fluidPage(

    DT::dataTableOutput(outputId = 'tbl', width = "100%", height = "400px")

            )

        )

   )

)
